package repository;

import com.google.gson.reflect.TypeToken;
import entity.History;
import utill.Utill;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HistoryRepository {
    UserRepository userRepository = new UserRepository();
    public void addHistory(History history) {
        List<History> histories = getAllHistories();
        histories.add(history);
        writeHistory(histories);
    }

    public void writeHistory(List<History> histories) {
        new Thread(() -> {
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(Utill.historyJsonUrl));
                writer.write(Utill.gson.toJson(histories));
                writer.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }).start();
    }

    public History getHistory(String firstPhoneNumber, String secondPhoneNumber) {
        List<History> histories = getAllHistories();
        for (History history : histories) {
            if (history.getFrom() == null || history.getTo() == null){
                continue;
            }
            if (Objects.equals(history.getFrom(), firstPhoneNumber) &&
            Objects.equals(history.getTo(), secondPhoneNumber)){
                return history;
            }
        }
        return null;
    }
    public List<History> getAllHistories() {
        ArrayList<History> histories = new ArrayList<>();
        try {
            histories = Utill.gson.fromJson(new FileReader(Utill.historyJsonUrl), new TypeToken<ArrayList<History>>() {
            }.getType());
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        return histories == null ? new ArrayList<>() : histories;
    }
}
