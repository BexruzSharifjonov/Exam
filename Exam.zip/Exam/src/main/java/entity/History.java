package entity;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class History {
    private String message;
    private String from;
    private String to;
}
