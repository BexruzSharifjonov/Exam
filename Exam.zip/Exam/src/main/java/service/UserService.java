package service;

import controller.UserController;
import entity.History;
import entity.User;
import repository.HistoryRepository;
import repository.UserRepository;
import utill.Utill;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class UserService {
    UserRepository userRepository = new UserRepository();
    HistoryRepository historyRepository = new HistoryRepository();

    public void signIn() {
        System.out.println("Enter your phone number");
        String number = Utill.strScanner.nextLine();
        User user = userRepository.getUser(number);
        if (user == null) {
            System.out.println("account with this number doesn't exist");
            return;
        }
        new UserController().userController(user);
    }

    public void signUp() {
        User user = new User();
        System.out.println("Enter your phone number(example: +998901111111)");
        user.setPhoneNumber(Utill.strScanner.nextLine());
        if (userRepository.getUser(user.getPhoneNumber()) != null) {
            System.out.println("This phone number already exists");
            return;
        }
        System.out.println("Account created successfully");
        userRepository.addUser(user);
    }

    public void writeToAnotherUser(User user) {
        List<User> allUsers = userRepository.getAllUsers();
        List<History> histories = historyRepository.getAllHistories();
        showContacts(user);
        System.out.println("Enter phone number: ");
        String phoneNumber = Utill.strScanner.nextLine();
        if (Objects.equals(phoneNumber, user.getPhoneNumber())) {
            System.out.println("You can't send message to yourself");
            return;
        }
        User secondUser = userRepository.getUser(phoneNumber);
        if (secondUser == null) {
            return;
        }
        user.setContacts(secondUser.getPhoneNumber());
        History history = new History();
            System.out.println("Enter message");
        history.setMessage(Utill.strScanner.nextLine());
        history.setFrom(user.getPhoneNumber());
        history.setTo(secondUser.getPhoneNumber());
        historyRepository.addHistory(history);
        userRepository.writeUsers(allUsers);
    }

    public void showMessages(User user) {
        List<History> allHistories = historyRepository.getAllHistories();
        System.out.println("Enter phone number");
        String phoneNumber = Utill.strScanner.nextLine();
        if (Objects.equals(phoneNumber, user.getPhoneNumber())) {
            System.out.println("You can't see messages that you sent to yourself");
            return;
        }
        User secondUser = userRepository.getUser(phoneNumber);
        if (secondUser == null) {
            return;
        }
        History history = historyRepository.getHistory(user.getPhoneNumber(), secondUser.getPhoneNumber());
        if (history == null) {
            System.out.println("You don't have any history");
            return;
        }
        for (History allHistory : allHistories) {
            if (Objects.equals(allHistory.getFrom(), user.getPhoneNumber()) && Objects.equals(allHistory.getTo(), secondUser.getPhoneNumber())){
                System.out.println(allHistory.getMessage());
            }
        }
    }

    public void showContacts(User user) {
        if (user.getContacts().size() != 0) {
            System.out.println("Your contacts");
        }
        for (String s : user.getContacts()) {
            System.out.println(s);
        }
    }
}
